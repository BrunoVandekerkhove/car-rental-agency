## Car Rental Agency

Experimenting with Java EE through the creation of a distributed car rental company.
