package session;

public class Session {
    
    private String name;
    
    public void initialize(String name) {
        this.name = name;
    }
    
}
